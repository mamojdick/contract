# -*- coding: utf-8 -*-
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import account_analytic_contract
from . import account_analytic_account
from . import account_analytic_contract_line
from . import account_analytic_invoice_line
from . import account_invoice
from . import res_partner
from . import res_company
